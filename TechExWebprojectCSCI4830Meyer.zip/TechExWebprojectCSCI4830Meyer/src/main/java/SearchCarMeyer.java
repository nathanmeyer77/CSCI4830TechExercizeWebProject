import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SearchCarMeyer")
public class SearchCarMeyer extends HttpServlet {
   private static final long serialVersionUID = 1L;

   public SearchCarMeyer() {
      super();
   }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String keyword = request.getParameter("keyword");
      String Description = request.getParameter("Description");
      search(keyword, Description, response);
   }

   void search(String keyword, String description, HttpServletResponse response) throws IOException {
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
      String title = "Car Data";
      String docType = "<!doctype html public \"-//w3c//dtd html 4.0 " + //
            "transitional//en\">\n"; //
      out.println(docType + //
            "<html>\n" + //
            "<head><title>" + title + "</title></head>\n" + //
            "<body bgcolor=\"#f0f0f0\">\n" + //
            "<h1 align=\"center\">" + title + "</h1>\n");

      Connection connection = null;
      PreparedStatement preparedStatement = null;
      try {
         DBConnection.getDBConnection();
         connection = DBConnection.connection;
         //System.out.print(connection);
         if (keyword.isEmpty()) {
            String selectSQL = "SELECT * FROM carInfo";
            preparedStatement = connection.prepareStatement(selectSQL);
         } else {
        	 String selectSQL = "";
        	switch(description) {
        	case "user":
        		selectSQL = "SELECT * FROM carInfo WHERE USER LIKE ?";
        		break;
        	case "make":
        		selectSQL = "SELECT * FROM carInfo WHERE MAKE LIKE ?";
        		break;
        	case "year":
        		selectSQL = "SELECT * FROM carInfo WHERE YEAR LIKE ?";
        		break;
        	case "color":
        		selectSQL = "SELECT * FROM carInfo WHERE COLOR LIKE ?";
        		break;
        	}
            //String selectSQL = "SELECT * FROM myTable WHERE DESCRIPTION LIKE ?";
            String desc = keyword + "%";
            preparedStatement = connection.prepareStatement(selectSQL);
            preparedStatement.setString(1, desc);
         }
         ResultSet rs = preparedStatement.executeQuery();

         while (rs.next()) {
            int id = rs.getInt("id");
            String userName = rs.getString("user").trim();
            String make = rs.getString("make").trim();
            String year = rs.getString("year").trim();
            String color = rs.getString("color").trim();
            String des = "";
            switch(description) {
        	case "user":
        		des = userName;
        		break;
        	case "make":
        		des = make;
        		break;
        	case "year":
        		des = year;
        		break;
        	case "color":
        		des = color;
        		break;
        	}
            if (keyword.isEmpty() || des.contains(keyword)) {
               out.println("ID: " + id + ", ");
               out.println("Owner: " + userName + ", ");
               out.println("Car Make: " + make + ", ");
               out.println("Car Year: " + year + ",");
               out.println("Color: " + color + "<br>");
            }
         }
         out.println("<a href=/TechExWebprojectCSCI4830Meyer/SearchCarMeyer.html>Back to Search</a> <br>");
         out.println("</body></html>");
         rs.close();
         preparedStatement.close();
         connection.close();
      } catch (SQLException se) {
         se.printStackTrace();
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            if (preparedStatement != null)
               preparedStatement.close();
         } catch (SQLException se2) {
         }
         try {
            if (connection != null)
               connection.close();
         } catch (SQLException se) {
            se.printStackTrace();
         }
      }
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doGet(request, response);
   }

}
